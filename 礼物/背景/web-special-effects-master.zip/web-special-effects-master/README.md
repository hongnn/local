网页效果预览：
http://htmlpreview.github.io/?https://github.com/mingxinZ/web-special-effects/blob/master/%E5%A4%9A%E5%BD%A9%E7%B2%92%E5%AD%90%E4%B8%8A%E6%B5%AE%E7%89%B9%E6%95%88.html
用canvas+JS撸了一个非常简单的网页特效：多彩粒子从下至上的浮动。
参考了掘金上一位前辈的小册：《如何使用canvas制作出炫酷的网页背景特效》
当然，我这个一点不炫酷，只是个基础，练手的。
嘿嘿，第一次在Github上发布。
也终于弄懂了如何在Github上预览网页效果。
    
    
